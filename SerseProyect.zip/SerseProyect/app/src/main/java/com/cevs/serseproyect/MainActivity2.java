package com.cevs.serseproyect;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

   public ImageButton btnpan, btnpri, btnindep, btnalianza, btnpt, btnprd, btnmorena, btnverde;
   public int idpan = 0, idpri = 0, idindep = 0,idalianza = 0, idpt = 0, idprd = 0, idmorena = 0, idverde = 0;
   String partidoselect;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnpan = findViewById(R.id.btnpan);
        btnpri = findViewById(R.id.btnpri);
        btnindep = findViewById(R.id.btnindep);
        btnalianza = findViewById(R.id.btnalianza);
        btnpt = findViewById(R.id.btnpt);
        btnprd = findViewById(R.id.btnprd);
        btnmorena = findViewById(R.id.btnmorena);
        btnverde = findViewById(R.id.btnverde);

        btnpan.setOnClickListener(this);
        btnpri.setOnClickListener(this);
        btnindep.setOnClickListener(this);
        btnalianza.setOnClickListener(this);
        btnpt.setOnClickListener(this);
        btnprd.setOnClickListener(this);
        btnmorena.setOnClickListener(this);
        btnverde.setOnClickListener(this);


    }
    private void  partidoSeleccionado(){
        // Create a new user with a first and last name
        Map<String, Object> user = new HashMap<>();
        user.put("voto", partidoselect);


// Add a new document with a generated ID
        db.collection("Ciudadano").document("VR1999").set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(),"si encontro",Toast.LENGTH_LONG).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),"no encontro",Toast.LENGTH_LONG).show();
                    }
                });
    }
    @Override
    public void onClick(View view) {
        idpan = btnpan.getId();
        idpri = btnpri.getId();
        idindep = btnindep.getId();
        idalianza = btnalianza.getId();
        idpt = btnpt.getId();
        idprd = btnprd.getId();
        idmorena = btnmorena.getId();
        idverde = btnverde.getId();
        int partido;

        partido = view.getId();

        if (partido == idpan) {
            partidoselect = "pan";
        }
        if (partido == idpri) {
            partidoselect = "pri";
        }
        if (partido == idindep) {
            partidoselect = "indep";
        }
        if (partido == idalianza) {
            partidoselect = "alianza";
        }
        if (partido == idpt) {
            partidoselect = "pt";
        }
        if (partido == idprd) {
            partidoselect = "prd";
        }
        if (partido == idmorena) {
            partidoselect = "morena";
        }
        if (partido == idverde) {
            partidoselect = "verde";
        }

        partidoSeleccionado();

    }
}