package com.cevs.serseproyect;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button validar;
    private EditText nom,curp,cla;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseAnalytics mFirebaseAnalytics;
    String cc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        nom=findViewById(R.id.nom);
        curp=findViewById(R.id.curp);
        cla=findViewById(R.id.cla);


        validar=findViewById(R.id.validar);
        validar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                consultar();
            }
        });
    }

    public void consultar(){
        cc=curp.getText().toString();
        db.collection("Ciudadano").document(cc).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()){
                            String nombre = documentSnapshot.getString("Nombre");
                            String curp = documentSnapshot.getString("Curp");
                            String elect = documentSnapshot.getString("Clave De Elector");
                            Toast.makeText(getApplicationContext(),"si encontro",Toast.LENGTH_LONG).show();
                            Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(getApplicationContext(),"no encontro",Toast.LENGTH_LONG).show();
                        }
                    }
                });
        //Toast.makeText(getApplicationContext(),"no encontro",Toast.LENGTH_LONG).show();

    }
}